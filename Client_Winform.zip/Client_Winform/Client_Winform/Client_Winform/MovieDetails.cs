﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;
using Client_Winform.Model;

namespace Client_Winform
{
    public partial class MovieDetails : Form
    {
        public MovieDetails(IEnumerable<Movie> result)
        {
            InitializeComponent();
            var mv = result?.FirstOrDefault();
            if (mv == null) return;
            title.Text = mv.title;
            yy.Text = $@"({mv.year})";
            ratingval.Text = mv.info.rating.ToString(CultureInfo.InvariantCulture);
            plotval.Text = mv.info.plot;
            RankValue.Text = mv.info.rank.ToString();
            var t = TimeSpan.FromSeconds(mv.info.running_time_secs);
            Durationval.Text = $"{t.Hours:D2}h:{t.Minutes:D2}m:{t.Seconds:D2}s:{t.Milliseconds:D3}ms";
            rdate.Text = mv.info.release_date.ToUniversalTime().ToString("yyyy-MM-dd");

            if (mv.info.directors !=null)
            {
                foreach (var dir in mv.info.directors)
                {
                    listBox1.Items.Add(dir);
                }
            }
            if (mv.info.genres != null)
            {
                foreach (var gen in mv.info.genres)
                {
                    listBox2.Items.Add(gen);
                }
            }
            if (mv.info.actors == null) return;
            foreach (var act in mv.info.actors)
            {
                listBox3.Items.Add(act);
            }
        }

        
    }
}
