﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Client_Winform.Model;
using Newtonsoft.Json;

namespace Client_Winform
{
    public partial class SearchMovie : Form
    {
        private List<Movie> _movies;
        List<DataGridMovie> _result;
        public SearchMovie()
        {
            InitializeComponent();
        }
        //Search function based on selection of radio button
        private void button1_Click(object sender, EventArgs e)
        {
            _movies = GetMovieData();

            if (textBox1.Text != string.Empty)
            {
                if (radioButton1.Checked)
                {
                    _result = PrepareDGClass(_movies.Where(x => x.title.ToLower().Contains(textBox1.Text.ToLower())));
                }
                else if (radioButton2.Checked)
                {
                    _result = PrepareDGClass(_movies.Where(x => x.year == int.Parse(textBox1.Text)));
                }
                else
                {
                    _result = PrepareDGClass(_movies.Where(x => x.info.rating == double.Parse(textBox1.Text)));
                }

                dataGridView1.DataSource = _result;
            }
            
        }

        //to prepare DGclass

        private List<DataGridMovie> PrepareDGClass(IEnumerable<Movie> getCurruntRecords)
        {
            return getCurruntRecords.Select(movie => new DataGridMovie()
                {
                    rank = movie.info.rank,
                    title = movie.title,
                    year = movie.year,
                    rating = movie.info.rating,
                    release_date = movie.info.release_date.ToUniversalTime().ToString("yyyy-MM-dd"),
                })
                .ToList();
        }

        //read movie data from json file and return list of movies
        private List<Movie> GetMovieData()
        {
            try
            {
                _movies = new List<Movie>();
                using (var file = File.OpenText(@"./App_Data/moviedata.json"))
                {
                    var serializer = new JsonSerializer();
                    _movies = (List<Movie>)serializer.Deserialize(file, typeof(List<Movie>));

                }
                //return movies by descending orders based on release year
                return _movies.OrderByDescending(x => x.year).ToList();
            }
            catch (Exception)
            {
                return null;
            }
        }

        //On title cell click of datagrid this event should be called to load details page of movie
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            var idx = e.RowIndex;
            var result = this._movies.Where(x => x.title == this._result[idx].title);
            var mv = new MovieDetails(result);
            mv.Show();
        }
    }
}
