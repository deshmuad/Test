﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Client_Winform.Model
{
    public class Movie
    {
        public int year { get; set; }
        public string title { get; set; }
        public Info info { get; set; }
    }
}
