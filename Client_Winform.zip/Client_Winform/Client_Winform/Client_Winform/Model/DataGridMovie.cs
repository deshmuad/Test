﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client_Winform.Model
{
   public class DataGridMovie
    {
        public int year { get; set; }
        public string title { get; set; }
        public double rating { get; set; }
        public string release_date { get; set; }
        public int rank { get; set; }
    }
}
