﻿namespace Client_Winform
{
    partial class MovieDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.yy = new System.Windows.Forms.Label();
            this.year = new System.Windows.Forms.Label();
            this.title = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.ratingval = new System.Windows.Forms.Label();
            this.rdate = new System.Windows.Forms.Label();
            this.Genres = new System.Windows.Forms.Label();
            this.Rating = new System.Windows.Forms.Label();
            this.Release_Date = new System.Windows.Forms.Label();
            this.directors = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.plotval = new System.Windows.Forms.Label();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.Durationval = new System.Windows.Forms.Label();
            this.RankValue = new System.Windows.Forms.Label();
            this.Actors = new System.Windows.Forms.Label();
            this.Duration = new System.Windows.Forms.Label();
            this.rank = new System.Windows.Forms.Label();
            this.plot = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.panel1.Controls.Add(this.yy);
            this.panel1.Controls.Add(this.year);
            this.panel1.Controls.Add(this.title);
            this.panel1.Location = new System.Drawing.Point(23, 78);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1052, 100);
            this.panel1.TabIndex = 0;
            // 
            // yy
            // 
            this.yy.AutoSize = true;
            this.yy.Location = new System.Drawing.Point(981, 63);
            this.yy.Name = "yy";
            this.yy.Size = new System.Drawing.Size(51, 20);
            this.yy.TabIndex = 11;
            this.yy.Text = "label1";
            // 
            // year
            // 
            this.year.AutoSize = true;
            this.year.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.year.Location = new System.Drawing.Point(882, 50);
            this.year.Name = "year";
            this.year.Size = new System.Drawing.Size(93, 36);
            this.year.TabIndex = 1;
            this.year.Text = " Year:";
            // 
            // title
            // 
            this.title.AutoSize = true;
            this.title.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.title.Location = new System.Drawing.Point(83, 35);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(76, 36);
            this.title.TabIndex = 0;
            this.title.Text = "Title";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel2.Controls.Add(this.listBox2);
            this.panel2.Controls.Add(this.listBox1);
            this.panel2.Controls.Add(this.ratingval);
            this.panel2.Controls.Add(this.rdate);
            this.panel2.Controls.Add(this.Genres);
            this.panel2.Controls.Add(this.Rating);
            this.panel2.Controls.Add(this.Release_Date);
            this.panel2.Controls.Add(this.directors);
            this.panel2.Location = new System.Drawing.Point(23, 214);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(482, 408);
            this.panel2.TabIndex = 1;
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 20;
            this.listBox2.Location = new System.Drawing.Point(142, 230);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(120, 84);
            this.listBox2.TabIndex = 9;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 20;
            this.listBox1.Location = new System.Drawing.Point(142, 27);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(120, 84);
            this.listBox1.TabIndex = 8;
            // 
            // ratingval
            // 
            this.ratingval.AutoSize = true;
            this.ratingval.Location = new System.Drawing.Point(157, 180);
            this.ratingval.Name = "ratingval";
            this.ratingval.Size = new System.Drawing.Size(86, 20);
            this.ratingval.TabIndex = 6;
            this.ratingval.Text = "ratingvalue";
            // 
            // rdate
            // 
            this.rdate.AutoSize = true;
            this.rdate.Location = new System.Drawing.Point(170, 134);
            this.rdate.Name = "rdate";
            this.rdate.Size = new System.Drawing.Size(56, 20);
            this.rdate.TabIndex = 5;
            this.rdate.Text = "RDate";
            // 
            // Genres
            // 
            this.Genres.AutoSize = true;
            this.Genres.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Genres.Location = new System.Drawing.Point(36, 230);
            this.Genres.Name = "Genres";
            this.Genres.Size = new System.Drawing.Size(68, 20);
            this.Genres.TabIndex = 3;
            this.Genres.Text = "Genres";
            // 
            // Rating
            // 
            this.Rating.AutoSize = true;
            this.Rating.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Rating.Location = new System.Drawing.Point(36, 180);
            this.Rating.Name = "Rating";
            this.Rating.Size = new System.Drawing.Size(62, 20);
            this.Rating.TabIndex = 2;
            this.Rating.Text = "Rating";
            // 
            // Release_Date
            // 
            this.Release_Date.AutoSize = true;
            this.Release_Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Release_Date.Location = new System.Drawing.Point(26, 134);
            this.Release_Date.Name = "Release_Date";
            this.Release_Date.Size = new System.Drawing.Size(119, 20);
            this.Release_Date.TabIndex = 1;
            this.Release_Date.Text = "Release Date";
            // 
            // directors
            // 
            this.directors.AutoSize = true;
            this.directors.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.directors.Location = new System.Drawing.Point(36, 60);
            this.directors.Name = "directors";
            this.directors.Size = new System.Drawing.Size(82, 20);
            this.directors.TabIndex = 0;
            this.directors.Text = "Directors";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel3.Controls.Add(this.plotval);
            this.panel3.Controls.Add(this.listBox3);
            this.panel3.Controls.Add(this.Durationval);
            this.panel3.Controls.Add(this.RankValue);
            this.panel3.Controls.Add(this.Actors);
            this.panel3.Controls.Add(this.Duration);
            this.panel3.Controls.Add(this.rank);
            this.panel3.Controls.Add(this.plot);
            this.panel3.Location = new System.Drawing.Point(533, 214);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(555, 408);
            this.panel3.TabIndex = 10;
            // 
            // plotval
            // 
            this.plotval.AutoSize = true;
            this.plotval.Location = new System.Drawing.Point(165, 60);
            this.plotval.Name = "plotval";
            this.plotval.Size = new System.Drawing.Size(54, 20);
            this.plotval.TabIndex = 10;
            this.plotval.Text = "plotval";
            // 
            // listBox3
            // 
            this.listBox3.FormattingEnabled = true;
            this.listBox3.ItemHeight = 20;
            this.listBox3.Location = new System.Drawing.Point(142, 230);
            this.listBox3.Name = "listBox3";
            this.listBox3.Size = new System.Drawing.Size(120, 84);
            this.listBox3.TabIndex = 9;
            // 
            // Durationval
            // 
            this.Durationval.AutoSize = true;
            this.Durationval.Location = new System.Drawing.Point(157, 180);
            this.Durationval.Name = "Durationval";
            this.Durationval.Size = new System.Drawing.Size(89, 20);
            this.Durationval.TabIndex = 6;
            this.Durationval.Text = "Durationval";
            // 
            // RankValue
            // 
            this.RankValue.AutoSize = true;
            this.RankValue.Location = new System.Drawing.Point(170, 134);
            this.RankValue.Name = "RankValue";
            this.RankValue.Size = new System.Drawing.Size(88, 20);
            this.RankValue.TabIndex = 5;
            this.RankValue.Text = "RankValue";
            // 
            // Actors
            // 
            this.Actors.AutoSize = true;
            this.Actors.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Actors.Location = new System.Drawing.Point(36, 230);
            this.Actors.Name = "Actors";
            this.Actors.Size = new System.Drawing.Size(61, 20);
            this.Actors.TabIndex = 3;
            this.Actors.Text = "Actors";
            // 
            // Duration
            // 
            this.Duration.AutoSize = true;
            this.Duration.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Duration.Location = new System.Drawing.Point(36, 180);
            this.Duration.Name = "Duration";
            this.Duration.Size = new System.Drawing.Size(78, 20);
            this.Duration.TabIndex = 2;
            this.Duration.Text = "Duration";
            // 
            // rank
            // 
            this.rank.AutoSize = true;
            this.rank.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rank.Location = new System.Drawing.Point(36, 134);
            this.rank.Name = "rank";
            this.rank.Size = new System.Drawing.Size(51, 20);
            this.rank.TabIndex = 1;
            this.rank.Text = "Rank";
            // 
            // plot
            // 
            this.plot.AutoSize = true;
            this.plot.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.plot.Location = new System.Drawing.Point(36, 60);
            this.plot.Name = "plot";
            this.plot.Size = new System.Drawing.Size(40, 20);
            this.plot.TabIndex = 0;
            this.plot.Text = "Plot";
            // 
            // MovieDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1100, 688);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "MovieDetails";
            this.Text = "MovieDetails";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label year;
        private System.Windows.Forms.Label title;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label Rating;
        private System.Windows.Forms.Label Release_Date;
        private System.Windows.Forms.Label directors;
        private System.Windows.Forms.Label Genres;
        private System.Windows.Forms.Label ratingval;
        private System.Windows.Forms.Label rdate;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ListBox listBox3;
        private System.Windows.Forms.Label Durationval;
        private System.Windows.Forms.Label RankValue;
        private System.Windows.Forms.Label Actors;
        private System.Windows.Forms.Label Duration;
        private System.Windows.Forms.Label rank;
        private System.Windows.Forms.Label plot;
        private System.Windows.Forms.Label plotval;
        private System.Windows.Forms.Label yy;
    }
}