﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Client_Winform.Model;
using Newtonsoft.Json;

namespace Client_Winform
{
    public partial class Home : Form
    {

        //Paging related fields
        private readonly int PageSize = 4;
        private int _currentPageIndex = 1;
        private int _totalPage;

        List<Movie>  _movies; 
        public Home()
        {
            InitializeComponent();
            //Initialize movie list to read data from data file
            dataGridView1.DataSource = _movies;
            dataGridView1.Refresh();
            

            //Home paging canculations and datagrid data source binding
            CalculateTotalPages();
            dataGridView1.ReadOnly = true;
            dataGridView1.DataSource = PrepareDgClass(GetCurruntRecords(_currentPageIndex, PageSize));
            label2.Text = _currentPageIndex.ToString();


        }
        //to prepare DGclass
        private static object PrepareDgClass(IEnumerable<Movie> getCurruntRecords)
        {
            return getCurruntRecords.Select(movie => new DataGridMovie
                {
                    rank = movie.info.rank,
                    title = movie.title,
                    year = movie.year,
                    rating = movie.info.rating,
                    release_date = movie.info.release_date.ToUniversalTime().ToString("yyyy-MM-dd"),
                })
                .ToList();
        }


        //Filter data based on page zise and currunt page
        private IEnumerable<Movie> GetCurruntRecords(int currentPageIndex,int pgSize)
        {
            _movies = GetMovieData();
            if (_movies != null) return _movies.Skip((currentPageIndex - 1) * pgSize).Take(pgSize).ToList();
            MessageBox.Show(Properties.Resources.DATA_LOAD_ERROR);
            return null;
        }


        //read data from json file
        private List<Movie> GetMovieData()
        {
            //as reading external file so used try catch to ahndle exception
            try
            {
                _movies = new List<Movie>();
                using (var file = File.OpenText(@"./App_Data/moviedata.json"))
                {
                    var serializer = new JsonSerializer();
                    _movies = (List<Movie>)serializer.Deserialize(file, typeof(List<Movie>));

                }
                //return movies by descending orders based on release year
                return _movies.OrderByDescending(x=>x.year).ToList();
            }
            catch (Exception)
            {
                return null;
            }
        }

        //this function used to calculate total number of pages based on json file data
        private void CalculateTotalPages()
        {
            _movies = GetMovieData();
            var rowCount = _movies.Count; 
            _totalPage = rowCount / PageSize;
             if (rowCount % PageSize > 0)
                _totalPage += 1;
        }

        //Open search page
        private void button1_Click(object sender, EventArgs e)
        {
           var search = new SearchMovie();
            search.Show();
            
        }

       
        //this function is responsible to load first page records
        private void button2_Click(object sender, EventArgs e)
        {
            _currentPageIndex = 1;
            dataGridView1.DataSource = PrepareDgClass(GetCurruntRecords(_currentPageIndex, PageSize));
            label2.Text = _currentPageIndex.ToString();
        }

        //this function is responsible to load previous page records
        private void button5_Click(object sender, EventArgs e)
        {
            _currentPageIndex = _totalPage;
            dataGridView1.DataSource = PrepareDgClass(GetCurruntRecords(_currentPageIndex, PageSize));
            label2.Text = _currentPageIndex.ToString();
        }
        //this function is responsible to load next page records
        private void button3_Click(object sender, EventArgs e)
        {
            if (_currentPageIndex <= 1) return;
            _currentPageIndex--;
            dataGridView1.DataSource = PrepareDgClass(GetCurruntRecords(_currentPageIndex, PageSize));
            label2.Text = _currentPageIndex.ToString();
        }
        //this function is responsible to load last page records
        private void button4_Click(object sender, EventArgs e)
        {
            if (_currentPageIndex >= _totalPage) return;
            _currentPageIndex++;
            dataGridView1.DataSource = PrepareDgClass(GetCurruntRecords(_currentPageIndex, PageSize));
            label2.Text = _currentPageIndex.ToString();
        }

       
    }

   
}
